# Sample Coding Questions 01 Week 01
# Vincenzo Iori